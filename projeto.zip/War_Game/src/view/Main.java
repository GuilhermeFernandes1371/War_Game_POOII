package view;

import control.ControladorDeJogo;

public class Main {

	public static void main(String[] args) {
		ControladorDeJogo jogo = new ControladorDeJogo();
	}

}
