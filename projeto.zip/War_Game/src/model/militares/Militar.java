package model.militares;

public abstract class Militar {
	
	public abstract String toString();
	public abstract int valorAtaque(); // Retorna um valor sorteado somado com o valor extra de cada especializacao
	
}
